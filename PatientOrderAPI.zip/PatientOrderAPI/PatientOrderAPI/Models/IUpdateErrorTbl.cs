﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PatientOrderAPI.Models;


namespace PatientOrderAPI.Models
{
    public interface IUpdateErrorTbl<T>
    {
        IEnumerable<T> UpdateErrorStorage(ErrorStorage model);
    }
}
