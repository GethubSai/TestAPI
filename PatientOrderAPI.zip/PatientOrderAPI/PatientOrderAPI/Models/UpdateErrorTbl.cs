﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PatientOrderAPI.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;


namespace PatientOrderAPI.Models 
{
   
    public class UpdateErrorTbl :IUpdateErrorTbl<ErrorStorage>
    {
        private readonly ApplicationDBContext _ApplicationDBContext;

        public UpdateErrorTbl(ApplicationDBContext context)
        {
            _ApplicationDBContext = context;
        }

        public IEnumerable<ErrorStorage> UpdateErrorStorage(ErrorStorage model)
        {
            //Add record into ErrorStorage table
            _ApplicationDBContext.ErrorStorage.Add(model);
            _ApplicationDBContext.SaveChanges();
            return _ApplicationDBContext.ErrorStorage.ToList();
        }

       
    }
}
