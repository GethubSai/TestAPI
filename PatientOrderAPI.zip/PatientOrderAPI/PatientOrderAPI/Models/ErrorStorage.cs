﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using PatientOrderAPI.Models;
using System.Web;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace PatientOrderAPI.Models
{
    public class ErrorStorage
    {
        [Key]
        public int Id  { get; set; }
        public string ErrorDescription { get; set; }
    }
}
