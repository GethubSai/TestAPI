﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Reflection;
using System.Data;
using PatientOrderAPI.Models;
using Newtonsoft.Json;
using log4net;
using log4net.Config;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PatientOrderAPI.Controllers
{
    [Route("api/[controller]")]
    public class PatientOrderController : Controller
    {
        public ErrorStorage errorStorage { get; set; }
        private readonly IUpdateErrorTbl<ErrorStorage> _updateErrorTbl;
        public static readonly log4net.ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public PatientOrderController(IUpdateErrorTbl<ErrorStorage> updateErrorTbl)
        {
            _updateErrorTbl = updateErrorTbl;
        }

        // GET: api/<controller>
        [HttpGet]
        public string Get(string orderStr)
        {
            //Log processing
            var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
            XmlConfigurator.Configure(logRepository, new FileInfo("log4net.config"));
            var logger = LogManager.GetLogger(typeof(Program));
            try
            {
                ErrorStorage model = new ErrorStorage();

                //Test strings
                //orderStr = "ORD|122|John Smith|Glucose";
               // orderStr = "ERR|Patient Not Found";

                string JSONString = string.Empty;

                //Parse Pipe delimited String
                string[] OrderRows = orderStr.Split('|');
                List<string> myList = new List<string>(); //make a new string list    
                myList.AddRange(OrderRows);

                if (myList[0].ToString() == "ORD")
                {
                    log.InfoFormat("Processing patient order data");
                    log.InfoFormat("JsonString Serialize patient order data: " + JSONString);
                    JSONString = JsonConvert.SerializeObject(myList);
                }
                else if (myList[0].ToString() == "ERR")
                {
                    log.InfoFormat("Processing patient order error string data");
                    model.ErrorDescription = myList[1].ToString();
                    // Update database
                    log.InfoFormat("Insert Error record into database table");
                    _updateErrorTbl.UpdateErrorStorage(model);
                    log.InfoFormat("ErrorStorage table update successful");
                    return "ErrorStorage table update successful";
                }
                  return JSONString;
            }

            catch (Exception ex)
            {
                log.Error("Error in patient order process ", ex);
                return "Patient order process failed";
            }
            finally
            {
                log.InfoFormat("Patient order process successfull");
            }
        }
         
    }
}
